/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.*;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.*;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author CHAIMA
 */
public class VendeurController implements Initializable {

    @FXML
    private AnchorPane anchor1;
    private JFXDrawer drawer;
    private JFXHamburger hamburger;
    @FXML
    private AnchorPane a1;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
     /*   HamburgerBackArrowBasicTransition burgerTask= new HamburgerBackArrowBasicTransition(hamburger);
        burgerTask.setRate(-1);
        EventHandler Ham = new EventHandler() {
            @Override
            public void handle(Event event) {
                burgerTask.setRate(burgerTask.getRate()* -1);
            burgerTask.play();
              if(drawer.isShown())
             drawer.isHidden();
        else
            drawer.isHidden();
        }
        };*/
     //  hamburger.addEventHandler(Mouse, Ham);
         a1.toBack();
 
}

    private void show(MouseDragEvent event) {
        a1.toFront();
    }

    private void show(javafx.scene.input.MouseEvent event) {
        a1.toFront();
    }
}
