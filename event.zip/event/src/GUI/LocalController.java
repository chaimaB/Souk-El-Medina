/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import entities.Local;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import service.ServiceLocal;


/**
 * FXML Controller class
 *
 * @author WIIW
 */
public class LocalController implements Initializable {
    @FXML
    private JFXButton AjoutLocal;
    @FXML
    private JFXTextField nom;
    @FXML
    private JFXTextField superficie;
    @FXML
    private JFXTextArea description;
    @FXML
    private JFXButton add;
    @FXML
    private JFXTextField localisation;
    
    //////////////////
    private Path to;
    private Path from;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void AjouertLocal(ActionEvent event) {

        Local local = new Local(description.getText(),
                nom.getText(),
                Integer.valueOf(superficie.getText()),
                localisation.getText()
        );
        ServiceLocal su = new ServiceLocal();
        su.AjouterLocal(local);


        
    } 
    

    @FXML
    private void AddAction(MouseEvent event) {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));

        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            try {
                from = Paths.get(selectedFile.toURI());
                to = Paths.get("Source Packages/assetes/" + selectedFile.getName());
                Files.copy(from, to);
            } catch (IOException ex) {
                Logger.getLogger(LocalController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
    
}
