/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.sql.Date;
import javafx.scene.control.DatePicker;


/**
 *
 * @author CHAIMA
 */
public class User {
     private int id ;
    private String cin ;
    private String nom ;
    private String prenom ;
    private String email ;
    private String pwd ;
    private Date dateN;
    private  int numTel;
    private String userName;
    private String image ;
    private  String adress;
    private int role ;
    private static User connectUser;

    public User(String cin, String nom, String prenom, String email, String pwd, Date dateN, int numTel, String userName, String image, String adress, int role) {
//        this.id = id;
        this.cin = cin;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.pwd = pwd;
        this.dateN = dateN;
        this.numTel = numTel;
        this.userName = userName;
        this.image = image;
        this.adress = adress;
        this.role = role;
    }

    public User() {
    }

    


    

   

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getAdresse() {
        return adress;
    }

    public void setAdresse(String adress) {
        this.adress = adress;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDateNaissance() {
        return dateN;
    }

    public void setDateNaissance(Date dateN) {
        this.dateN = dateN;
    }

    

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public static User getConnectUser() {
        return connectUser;
    }

    public static void setConnectUser(User connectUser) {
        User.connectUser = connectUser;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getNumTel() {
        return numTel;
    }

    public void setNumTel(int numTel) {
        this.numTel = numTel;
    }

    public String getPwd() {
        return pwd;
    }

    public int getRole() {
        return role;
    }

    

    public void setRole(int role) {
        this.role = role;
    }
    

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getUsername() {
        return userName;
    }

    public void setUsername(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return "User {"+"";
    }
    
    
}
