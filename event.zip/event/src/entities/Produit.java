/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;

/**
 *
 * @author CHAIMA
 */
public class Produit {
     private int ref ;
     private String nomP;
     private float prix;
     private String nomV;
     private Date dateAjout;

    public Produit(int ref, String nomP, float prix, String nomV, Date dateAjout) {
        this.ref = ref;
        this.nomP = nomP;
        this.prix = prix;
        this.nomV = nomV;
        this.dateAjout = dateAjout;
    }
     
     

    public int getRef() {
        return ref;
    }

    public void setRef(int ref) {
        this.ref = ref;
    }

    public String getNomP() {
        return nomP;
    }

    public void setNomP(String nomP) {
        this.nomP = nomP;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public String getNomV() {
        return nomV;
    }

    public void setNomV(String nomV) {
        this.nomV = nomV;
    }

    public Date getDateAjout() {
        return dateAjout;
    }

    public void setDateAjout(Date dateAjout) {
        this.dateAjout = dateAjout;
    }
     
     
}
