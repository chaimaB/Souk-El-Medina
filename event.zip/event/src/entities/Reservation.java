/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import entities.Event;
/**
 *
 * @author CHAIMA
 */
public class Reservation {
    private int id_reservation;
    private Date date_debut;
    private Date date_fin;
    private  String event;
    private String owner;

    public Reservation(int id_reservation, Date date_debut, Date date_fin, String event, String owner) {
        this.id_reservation = id_reservation;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.event = event;
        this.owner = owner;
    }
    
    

    public int getId_reservation() {
        return id_reservation;
    }

    public void setId_reservation(int id_reservation) {
        this.id_reservation = id_reservation;
    }

    public Date getDate_debut() {
        return date_debut;
    }

    public void setDate_debut(Date date_debut) {
        this.date_debut = date_debut;
    }

    public Date getDate_fin() {
        return date_fin;
    }

    public void setDate_fin(Date date_fin) {
        this.date_fin = date_fin;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }
    
    
    
}
