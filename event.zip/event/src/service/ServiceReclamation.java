/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Reclamation;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author CHAIMA
 */
public class ServiceReclamation {
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
     public ServiceReclamation(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceReclamation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public void AjouterReclamation(Reclamation r) throws SQLException{
        String req="INSERT INTO reclamation (id,reclameur,reclamee,nbrreclam,date) VALUES(?,?,?,?,?)";
        PreparedStatement pre = con.prepareStatement(req);
        pre.setInt(1,r.getId());
        pre.setString(2, r.getReclameur());
        pre.setString(3, r.getReclamee());
        pre.setInt(4, r.getNbrreclam()+1);
        pre.setDate(5, (Date) r.getDate());
        pre.executeUpdate();
        System.out.println("Reclamation ajoutee");
       }
       public void update(Reclamation r,int id){
        try {
            String req;
            req = "UPDATE reclamation SET `id`=?,`reclameur`=?,`reclamee`=?,`nbrreclam`=?,`date`=? WHERE id="+id;
            
            PreparedStatement pre=con.prepareStatement(req);
            pre.setInt(1,id);
        pre.setString(2, r.getReclameur());
        pre.setString(3, r.getReclamee());
        pre.setInt(4, r.getNbrreclam());
        pre.setDate(5, (Date) r.getDate());
            pre.executeUpdate();
            System.out.println(pre.execute());
            System.out.println("Modification avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceReclamation.class.getName()).log(Level.SEVERE, null, ex);
        }
}
public void supprimer(int id){

        try {
            String req = "DELETE FROM reclamation WHERE id=?";
            PreparedStatement ste1=con.prepareStatement(req);
            ste1.setInt(1, id);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceReclamation.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
    }

    
}
