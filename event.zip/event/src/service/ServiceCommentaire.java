/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Commentaire;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author CHAIMA
 */
public class ServiceCommentaire {
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
     public ServiceCommentaire(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceCommentaire.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
       public void AjouterCommentaire(Commentaire co) throws SQLException{
        String req="INSERT INTO commentaire (contenu,date) VALUES(?,?)";
        PreparedStatement pre = con.prepareStatement(req);
        pre.setString(1, co.getContenu());
        pre.setDate(2, (Date) co.getDate());
        pre.executeUpdate();
        System.out.println("Commentaire ajoutee");
       }
       public void update(Commentaire co,int id){
        try {
            String req;
            req = "UPDATE commentaire SET `contenu`=?,`date`=? WHERE id="+id;
            
            PreparedStatement pre=con.prepareStatement(req);
            pre.setString(1, co.getContenu());
            pre.setDate(2, new Date(118));
            pre.executeUpdate();
            System.out.println(pre.execute());
            System.out.println("Modification avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceCommentaire.class.getName()).log(Level.SEVERE, null, ex);
        }
}
public void supprimer(int id){

        try {
            String req = "DELETE FROM commentaire WHERE id="+id;
            PreparedStatement ste1=con.prepareStatement(req);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceCommentaire.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
    }
}
