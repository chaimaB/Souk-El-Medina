/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Local;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import static service.ServiceUser.su;
import utils.DataSource;

/**
 *
 * @author CHAIMA
 */
public class ServiceLocal {
    public static ServiceLocal su;

    public static ServiceLocal getInstance() {
        if(su == null )
            su = new ServiceLocal();
        return su;
            
    }
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
    
    public ServiceLocal(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceLocal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterLocal(Local u) {
        try {
            String req="INSERT INTO local (description,nom_local,superficie,localisation) VALUES(?,?,?,?)";
            PreparedStatement pre = con.prepareStatement(req);
            
            
            pre.setString(1, u.getDescription() );
            pre.setString(2, u.getNom_local()  );
            
            pre.setInt(3,  (int)u.getSuperficie() );
            pre.setString(4, u.getLocalisation() );
            
            pre.executeUpdate();
            System.out.println("Local ajoutée");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceLocal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void update(Local u,int id_local){
        try {
            String req;
            req = "UPDATE Local SET `id_local`=?,`description`=?,`nom_local`=?,`prix`=?,`superficie`=?,`localisation`=?,`imgl1`=?,`type`=? WHERE id_local="+id_local;
            
            PreparedStatement pre=con.prepareStatement(req);
            
         pre.setInt(1, id_local);
         pre.setString(2, u.getDescription());
        pre.setString(3, u.getNom_local());
        pre.setInt(4, (int)u.getPrix());
        pre.setInt(5,(int) u.getSuperficie());
        pre.setString(6, u.getLocalisation());
        pre.setString(7, u.getImgl1());
        pre.setInt(8,(int) u.getType());
        
            pre.executeUpdate();
            System.out.println(pre.execute());
            System.out.println("Modification avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceLocal.class.getName()).log(Level.SEVERE, null, ex);
        }
}
     public void supprimer(int id){

        try {
            String req = "DELETE FROM Local WHERE id_local=? ";
            PreparedStatement ste1=con.prepareStatement(req);
            ste1.setInt(1, id);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceLocal.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
    }
     
      public ResultSet afficher(){
         ResultSet resultat = null;
         // String req = "SELECT * FROM Local";
             String req =" SELECT `id_local`, `description`, `nom_local`, `prix`, `superficie`, `localisation`, `imgl1`, `type`, `prop` FROM `local`";
        try {
           
            PreparedStatement ste=con.prepareStatement(req);
            resultat = ste.executeQuery();
            
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
         return resultat;
     }
}
