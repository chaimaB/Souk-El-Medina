/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.sql.Date;

/**
 *
 * @author WIIW
 */
public class Dispo {
    private int id_dispo;
    private Date date;
    public int local;

    public Dispo(Date date, int local) {
        this.date = date;
        this.local = local;
    }

    public int getId_dispo() {
        return id_dispo;
    }

    public Date getDate() {
        return date;
    }

    public int getLocal() {
        return local;
    }

    public void setId_dispo(int id_dispo) {
        this.id_dispo = id_dispo;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setLocal(int local) {
        this.local = local;
    }
    
}
