/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import entities.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Odil
 */
public class Authentification {
    
    private Connection cnx;
    public static Authentification instance;
    public static User user;
    
    public Authentification()
    {
    cnx=DataSource.getInstance().getConnection();
    user=null;
    }
    
    
    public static Authentification getSession()
    {if(instance==null)
    instance=new Authentification();
    return instance;
    }
           
    public boolean login(String username,String pwd){
        if (user==null){
             String req = "SELECT * FROM `user` WHERE username = ? and pwd = ?";
             
             try{
                    PreparedStatement ps = cnx.prepareStatement(req);
                    ps.setString(1, username);
                    ps.setString(2, pwd);
                    
                    ResultSet r = ps.executeQuery();

                    if(r.next()){
                        user= new User(r.getInt("id"), r.getString("email"), r.getString("pwd"), r.getString("userName"),r.getInt("role"));
                        return true;
                    }
                                      
                }
                catch(SQLException ex){
                    return false;
                }
        }
        return false;
    }
    
    public boolean connected(){
        return user!=null;
    }
    
    public void logout(){
        user=null;
    }
    
    public User getUser(){
        if (connected()) return user;
        return null;
    }
}
