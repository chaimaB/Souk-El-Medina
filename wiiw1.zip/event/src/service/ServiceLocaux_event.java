/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;
import entities.Locaux_event;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author CHAIMA
 */
public class ServiceLocaux_event {
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
    
    public ServiceLocaux_event(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceLocaux_event.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterLocal(Locaux_event u) throws SQLException{
        String req="INSERT INTO Locaux_event (description,nom_local,prix,superficie,localisation,prop) VALUES(?,?,?,?,?,?)";
        PreparedStatement pre = con.prepareStatement(req);
         
        pre.setString(1, u.getDescription());
        pre.setString(2, u.getNom_local());
        pre.setInt(3, (int)u.getPrix());
        pre.setInt(4,(int) u.getSuperficie());
        pre.setString(5, u.getLocalisation());
        pre.setInt(6, u.getProp());

    


        pre.executeUpdate();
        System.out.println("Local_event ajoutée");
    }
    
    public void update(Locaux_event u,int id_local_event){
        try {
            String req;
            req = "UPDATE Locaux_event SET `id_local_event`=?,`description`=?,`nom_local`=?,`prix`=?,`superficie`=?,`localisation`=?,`imgl1`=?,`status`=? WHERE id_local_event="+id_local_event;
            
            PreparedStatement pre=con.prepareStatement(req);
            
         pre.setInt(1, id_local_event);
         pre.setString(2, u.getDescription());
        pre.setString(3, u.getNom_local());
        pre.setInt(4, (int)u.getPrix());
        pre.setInt(5,(int) u.getSuperficie());
        pre.setString(6, u.getLocalisation());
        pre.setString(7, u.getImgl1());
        pre.setInt(8,(int) u.getStatus());
        
            pre.executeUpdate();
            System.out.println(pre.execute());
            System.out.println("Modification avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceLocaux_event.class.getName()).log(Level.SEVERE, null, ex);
        }
}
     public void supprimer(int id){

        try {
            String req = "DELETE FROM Locaux_event WHERE id_local_event=? ";
            PreparedStatement ste1=con.prepareStatement(req);
            ste1.setInt(1, id);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceLocaux_event.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
    }
}
