/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Dispo;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author CHAIMA
 */
public class ServiceDispo {
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
    
    public ServiceDispo(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDispo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterDispo(Dispo u) throws SQLException{
        String req="INSERT INTO Dispo (date,local) VALUES(?,?)";
        PreparedStatement pre = con.prepareStatement(req);
      
      
        pre.setDate(1,(Date) u.getDate());       
          pre.setInt(2,u.getLocal());
    


        pre.executeUpdate();
        System.out.println("Local ajoutée");
    }
    
    public void update_dispo(Dispo u){
        try {
            String req;
            req = "UPDATE Dispo SET `date`=? WHERE local="+u.getLocal();
            
            PreparedStatement pre=con.prepareStatement(req);
            
         pre.setDate(1,(Date) u.getDate());
         
        
            pre.executeUpdate();
            System.out.println(pre.execute());
            System.out.println("Modification avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDispo.class.getName()).log(Level.SEVERE, null, ex);
        }
}
     public void supprimer_dispo(int id){

        try {
            String req = "DELETE FROM Local WHERE id_local=? ";
            PreparedStatement ste1=con.prepareStatement(req);
            ste1.setInt(1, id);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDispo.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
    }
}
