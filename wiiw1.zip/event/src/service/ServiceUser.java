/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;
import entities.User;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;


/**
 *
 * @author CHAIMA
 */
public class ServiceUser {
    public static ServiceUser su;

    public static ServiceUser getInstance() {
        if(su == null )
            su = new ServiceUser();
        return su;
            
    }
    
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
    
    public ServiceUser(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterUser(User u) throws SQLException{
        String req="INSERT INTO user (cin,nom,prenom,email,pwd,dateN,numTel,userName,image,adress,role) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement pre = con.prepareStatement(req);
      // pre.setInt(1, 0);
        pre.setString(1, u.getCin());
        pre.setString(2, u.getNom());
        pre.setString(3, u.getPrenom());
        pre.setString(4, u.getEmail());
        pre.setString(5, u.getPwd());
        pre.setDate(6,(Date) u.getDateNaissance());
        pre.setInt(7, (int) u.getNumTel());
        pre.setString(8, u.getUsername());
        pre.setString(9, u.getImage());
        pre.setString(10, u.getAdresse());

        pre.setInt(11, u.getRole());


        pre.executeUpdate();
        System.out.println("User ajoutée");
    }
    
    public void update(User u,int id){
        try {
            String req;
            req = "UPDATE user SET `nom`=?,`prenom`=?,`email`=?,`pwd`=?,`dateN`=?,`numTel`=?,`userName`=?,`image`=?,`adress`=?,`role`=? WHERE id=?";
            
            PreparedStatement pre=con.prepareStatement(req);
           // pre.setInt(1, id);
            pre.setString(1, u.getCin());
            pre.setString(2, u.getNom());
            pre.setString(3, u.getPrenom());
            pre.setString(4, u.getEmail());
            pre.setString(5, u.getPwd());
            pre.setDate(6,(Date) u.getDateNaissance());
            pre.setInt(7, (int) u.getNumTel());
            pre.setString(8, u.getUsername());
            pre.setString(9, u.getImage());
            pre.setString(10, u.getAdresse());
            pre.setInt(11, u.getRole());
            pre.executeUpdate();
            System.out.println(pre.execute());
            System.out.println("Modification avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
}
     public void supprimer(int id){

        try {
            String req = "DELETE FROM user WHERE id=?";
            PreparedStatement ste1=con.prepareStatement(req);
            ste1.setInt(1, id);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
    }
     
     public ResultSet afficher(){
         ResultSet resultat = null;
          String req = "SELECT * FROM user";
        try {
           
            PreparedStatement ste=con.prepareStatement(req);
            resultat = ste.executeQuery();
            
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
         return resultat;
     }
}
