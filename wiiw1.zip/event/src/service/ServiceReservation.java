/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Reservation;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author CHAIMA
 */
public class ServiceReservation {
     public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
    
    public ServiceReservation(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceReservation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterReservation(Reservation r) throws SQLException{
        String req="INSERT INTO reservation (id_reservation,date_debut,date_fin,event , owner) VALUES(?,?,?,?,?)";
        PreparedStatement pre = con.prepareStatement(req);
       pre.setInt(1, r.getId_reservation());
        pre.setDate(2,(Date)r.getDate_debut());
        pre.setDate(3,(Date) r.getDate_fin());
        pre.setString(4, r.getEvent());
        pre.setString(5, r.getOwner());
       
        pre.executeUpdate();
        System.out.println("reservation ajoutée");
    }
    
    public void SupprimerReserevation(int id){

        try {
            String req = "DELETE FROM reservation WHERE id_reservation=?";
            PreparedStatement ste1=con.prepareStatement(req);
            ste1.setInt(1, id);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceReservation.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
     } 
    
     public void UpdateReservation(Reservation r,int id){
        try {
            String req;
            req = "UPDATE reservation SET `id_reservation`=?,`date_debut`=?,`date_fin`=?,`event`=?,`owner`=? WHERE id_reservation="+id;
            
            PreparedStatement pre=con.prepareStatement(req);
            pre.setInt(1, id);
        pre.setDate(2,(Date) r.getDate_debut());
       pre.setDate(3,(Date) r.getDate_fin());
        pre.setString(4, r.getEvent());
        pre.setString(5, r.getOwner());
            pre.executeUpdate();
            System.out.println(pre.execute());
            System.out.println("Modification avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceReservation.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    
}
