/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;
import entities.Commande;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;


/**
 *
 * @author CHAIMA
 */
public class ServiceCommande {
    
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
    public ServiceCommande(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceCommande.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void AjouterCommande(Commande c) throws SQLException{
        String req="INSERT INTO commande (id_commande,datec,prix) VALUES(?,?,?)";
        PreparedStatement pre = con.prepareStatement(req);
       pre.setInt(1, 0);
        pre.setDate(2, (Date) c.getDatec());
        pre.setFloat(3, c.getPrix());
         pre.executeUpdate();
        System.out.println("commande passée avec succès");
    }
      public void updatecommande(Commande c,int id_commande){
        try {
            String req;
            req = "UPDATE commande SET `id_commande`=?,`datec`=?,`prix`=? WHERE id_commande="+id_commande;
            
            PreparedStatement pre=con.prepareStatement(req);
            pre.setInt(1, id_commande);
            pre.setDate(2,(Date) c.getDatec());
            pre.setFloat(3, c.getPrix());
            pre.executeUpdate();
         } catch (SQLException ex) {
            Logger.getLogger(ServiceCommande.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
       public void supprimerCommande(int id_commande){

        try {
            String req = "DELETE FROM commande WHERE id_commande="+id_commande;
            PreparedStatement ste1=con.prepareStatement(req);
            //ste1.setInt(1, id_commande);
            ste1.executeUpdate();
            System.out.println(ste1.execute());
         System.out.println("suppression avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceCommande.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
}
