/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.time.LocalDate;

/**
 *
 * @author CHAIMA
 */
public class Dispo {
    private int id_dispo;
    public int local;
    private Date startdate;
    private Date enddate;

    public Dispo(int id_dispo, int local, Date startdate, Date enddate) {
        this.id_dispo = id_dispo;
        this.local = local;
        this.startdate = startdate;
        this.enddate = enddate;
    }

    public int getId_dispo() {
        return id_dispo;
    }

    public int getLocal() {
        return local;
    }

    public Date getStartdate() {
        return startdate;
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setId_dispo(int id_dispo) {
        this.id_dispo = id_dispo;
    }

    public void setLocal(int local) {
        this.local = local;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    
    

    
    
    
}
