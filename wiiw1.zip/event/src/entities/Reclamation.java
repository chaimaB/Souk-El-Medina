/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;

/**
 *
 * @author CHAIMA
 */
public class Reclamation {
     private int id ;
    private String reclameur;
    private String reclamee;
    private int nbrreclam;
        private Date date;

    public Reclamation(int id, String reclameur, String reclamee, int nbrreclam, Date date) {
        this.id = id;
        this.reclameur = reclameur;
        this.reclamee = reclamee;
        this.nbrreclam = nbrreclam;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getReclameur() {
        return reclameur;
    }

    public void setReclameur(String reclameur) {
        this.reclameur = reclameur;
    }

    public String getReclamee() {
        return reclamee;
    }

    public void setReclamee(String reclamee) {
        this.reclamee = reclamee;
    }

    public int getNbrreclam() {
        return nbrreclam;
    }

    public void setNbrreclam(int nbrreclam) {
        this.nbrreclam = nbrreclam;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
   @Override
    public String toString() {
        return "Reclamation{" + "id=" + id + ", reclameur=" + reclameur + ", reclamee=" + reclamee + ", nbrreclam=" + nbrreclam + ", date=" + date + '}';
    } 
        
}
