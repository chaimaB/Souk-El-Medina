/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;

/**
 *
 * @author WIIW
 */
public class Annonce {
    private int id;
   
    private Date startdate;
    private Date enddate;
    public int id_local;
    public int id_prop;
    private float prix;
    private int type;

    public Annonce(int id, Date startdate, Date enddate, int id_local, int id_prop, float prix, int type) {
        this.id = id;
        this.startdate = startdate;
        this.enddate = enddate;
        this.id_local = id_local;
        this.id_prop = id_prop;
        this.prix = prix;
        this.type = type;
    }

 

    
    
    
    public int getId() {
        return id;
    }

    public Date getStartdate() {
        return startdate;
    }

    public Date getEnddate() {
        return enddate;
    }

    public int getId_local() {
        return id_local;
    }

    public float getPrix() {
        return prix;
    }

    public int getType() {
        return type;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    public void setId_local(int id_local) {
        this.id_local = id_local;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public void setType(int type) {
        this.type = type;
    }
    
    
}
