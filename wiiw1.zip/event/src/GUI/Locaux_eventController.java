/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import entities.Local;
import entities.Locaux_event;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import service.ServiceLocal;
import service.ServiceLocaux_event;
import utils.Authentification;

/**
 * FXML Controller class
 *
 * @author WIIW
 */
public class Locaux_eventController implements Initializable {
    @FXML
    private JFXTextField nom;
    @FXML
    private JFXTextField prix;
    @FXML
    private JFXTextField localisation;
    @FXML
    private JFXTextField superficie;
    @FXML
    private JFXTextArea description;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ajouter(ActionEvent event) {
        try {
            Authentification session=Authentification.getSession();
            Locaux_event local = new Locaux_event(
                    description.getText(),
                    nom.getText(),
                    Integer.valueOf(prix.getText()),
                    Integer.valueOf(superficie.getText()),
                    localisation.getText(),
                    session.getUser().getId()
            );
            
            
            
            ServiceLocaux_event su = new ServiceLocaux_event();
            su.AjouterLocal(local);
        } catch (SQLException ex) {
            Logger.getLogger(Locaux_eventController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
