/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import entities.Local;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import service.ServiceLocal;
import utils.Authentification;
import utils.DataSource;


/**
 * FXML Controller class
 *
 * @author WIIW
 */
public class LocalController implements Initializable {
    @FXML
    private JFXButton AjoutLocal;
    @FXML
    private JFXTextField nom;
    @FXML
    private JFXTextField superficie;
    @FXML
    private JFXTextArea description;
    @FXML
    private JFXButton add;
    @FXML
    private JFXTextField localisation;
    
    //////////////////
    private Path to;
    private Path from;
    //private Object primaryStage;

    @FXML
    private AnchorPane AnchorePane1;
    @FXML
    private WebView webView;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        //Stage stage = new Stage();
//       // final WebView webView = new WebView(); 
//        final WebEngine webEngine = new WebEngine();
//       
//        final Scene scene = new Scene(webView, 350, 300); 
////        stage.setTitle("Test de chargement de WebView"); 
////    stage.setScene(scene); 
////        stage.show(); 
//        
     
      
               
       webView.getEngine().load(getClass().getResource("Connector.html").toExternalForm()); 
    }
        // TODO
    
    public Connection con = DataSource.getInstance().getConnection() ;
       public Statement ste;

    @FXML
    private void AjouertLocal(ActionEvent event) {
        Authentification session = Authentification.getSession();

        Local local = new Local(description.getText(),
                nom.getText(),
                Integer.valueOf(superficie.getText()),
                localisation.getText(),
                null,
                session.getUser().getId()
        );
        ServiceLocal su = new ServiceLocal();
        su.AjouterLocal(local);
        System.out.println( session.getUser().getId());


        
    } 
    
  
    

    @FXML
    private void AddAction(MouseEvent event) {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));

        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            try {
                from = Paths.get(selectedFile.toURI());
                to = Paths.get("Source Packages/assetes/" + selectedFile.getName());
                Files.copy(from, to);
            } catch (IOException ex) {
                Logger.getLogger(LocalController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
    
}
