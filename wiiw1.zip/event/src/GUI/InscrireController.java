/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import entities.User;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import service.ServiceUser;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author CHAIMA
 */
public class InscrireController implements Initializable {

    @FXML
    private JFXButton sincrire;
    private JFXTextField cin;
    private JFXTextField numTel;
    @FXML
    private JFXTextField nom;
    private JFXTextField prenom;
    private JFXTextField userName;
    private JFXTextField email;
    private DatePicker dateN;
    private JFXTextField adress;
    private JFXPasswordField pwd;
    private JFXTextField role;
    private JFXTextField image;
    @FXML
    private JFXTextField superficie;
    @FXML
    private JFXTextArea localisation;
    @FXML
    private JFXButton add;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void inscription(ActionEvent event) throws IOException {
        
       // User u1=new User(0, cin, nom, prenom, email, pwd, dateN, 0, userName, image, adress, 0);
      /* TextField nom = new TextField();
       nom.getPromptText();*/
              

        User u = new User(cin.getText(),
                nom.getText(),
                prenom.getText(),
                email.getText(),
                pwd.getText(),
                //new Date(01/01/1999),
                Date.valueOf(dateN.getValue()),
                Integer.valueOf(numTel.getText()),

                userName.getText(),
                image.getText(),
                adress.getText(),
                Integer.valueOf(role.getText()));
        ServiceUser su = new ServiceUser();
        System.out.println("9bal l'ajout");
        try {
            su.AjouterUser(u);
            System.out.println("ba3d l'ajout");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Inscrire.fxml"));
            Parent root = loader.load();
           // SuccesController sc = loader.getController();
            //sc.setSucces("Voiture : -"+MarqueTxt.getText()+" "+CouleurTxt.getText()+"- ajoutée avec succés");
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("ba3d lbe9i");
                  Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("info");
                alert.setHeaderText("Ajout avec succés");
                //alert.setContentText("Votre ");
                alert.show();
             FXMLLoader loader1 = new FXMLLoader(getClass().getResource("AffichageUser.fxml"));
              Parent root1 = loader1.load();
           // SuccesController sc = loader.getController();
            //sc.setSucces("Voiture : -"+MarqueTxt.getText()+" "+CouleurTxt.getText()+"- ajoutée avec succés");
            Stage stage1 = new Stage();
            Scene scene1 = new Scene(root1);
            stage1.setScene(scene1);
            stage1.show();
                } catch (SQLException ex) {
            Logger.getLogger(InscrireController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

  
    
}
