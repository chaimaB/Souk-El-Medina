/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import entities.Local;
import entities.User;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import service.ServiceLocal;
import service.ServiceUser;
import static sun.misc.Version.println;
import utils.DataSource;

/**
 * FXML Controller class
 *
 * @author WIIW
 */
public class AffichageController implements Initializable {
    
       public Connection con = DataSource.getInstance().getConnection() ;
       public Statement ste;
   
    @FXML
    private TableView<Local> tableview;


    private ObservableList<Local> data;
    
    @FXML
    private TableColumn<Local, Integer> c1=new TableColumn<>();
    @FXML
    private TableColumn<Local, String> c2=new TableColumn<>();
    @FXML
    private TableColumn<Local, String> c3=new TableColumn<>();
//    @FXML
//    private TableColumn<Local, Integer> c4=new TableColumn<>();
    @FXML
    private TableColumn<Local, Integer> c4=new TableColumn<>();
    @FXML
    private TableColumn<Local, String> c5=new TableColumn<>();
  //  private TableColumn<Local, String> c7=new TableColumn<>();
    @FXML
    private JFXButton delete;
    @FXML
    private JFXTextField new_nom;
    @FXML
    private JFXTextField new_superficie;
    @FXML
    private JFXTextField new_localisation;
    
    @FXML
    private JFXButton Modifier;
    @FXML
    private JFXTextArea new_description;
    @FXML
    private JFXButton savebtn;
    
    
    
    
     public AffichageController(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Local u = new Local();
        c1.setCellValueFactory(new PropertyValueFactory<Local, Integer>("id_local"));
        c2.setCellValueFactory(new PropertyValueFactory<Local, String>("nom_local"));
        c3.setCellValueFactory(new PropertyValueFactory<Local, String>("description"));
       // c4.setCellValueFactory(new PropertyValueFactory<Local, Integer>("prix"));
        c4.setCellValueFactory(new PropertyValueFactory<Local, Integer>("superficie"));
        c5.setCellValueFactory(new PropertyValueFactory<Local, String>("localisation"));

        //c7.setCellValueFactory(new PropertyValueFactory<Local, String>("imgl1"));
       // c8.setCellValueFactory(new PropertyValueFactory<Local, Integer>("type"));
        //c9.setCellValueFactory(new PropertyValueFactory<Local, Integer>("prop"));
        
       
        buildData();
        
          
        // TODO
////        tableview.setEditable(true);
////        c1.setEditable(true);
////
////        c2.setEditable(true);
////        c3.setEditable(true);
////        c2.setCellFactory(TextFieldTableCell.forTableColumn());
////        c3.setCellFactory(TextFieldTableCell.forTableColumn());
       // c4.setCellFactory(TextFieldTableCell.forTableColumn());
       // c5.setCellFactory(TextFieldTableCell.forTableColumn());
//        c6.setCellFactory(TextFieldTableCell.forTableColumn());
//        c7.setCellFactory(TextFieldTableCell.forTableColumn());

                        
    }
    
    
     private void buildData() {
       ServiceLocal su = ServiceLocal.getInstance();
        data=FXCollections.observableArrayList();
       
        try {
             ResultSet r = su.afficher();
            while(r.next()){
                
                Local u = new Local();
                u.setId_Local(r.getInt("id_local"));
                
                u.setNom_local(r.getString("nom_local"));
                u.setDescription(r.getString("description"));
                
                
                u.setSuperficie(r.getInt("superficie"));
                u.setLocalisation(r.getString("localisation"));
//                u.setImgl1(r.getString("imgl1"));
//                u.setType(r.getInt("type"));
//                u.setProp(r.getInt("prop"));
//               
               
              data.add(u);
            }
            tableview.setItems(null);
            tableview.setItems(data);
//            tableview.setEditable(true);
//            c1.setEditable(true);
//            c2.setEditable(true);
//            c3.setEditable(true);
        } catch (SQLException ex) {
            Logger.getLogger(AffichageUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     
    @FXML
      public void Delete(){
        ServiceLocal su = ServiceLocal.getInstance();
        ObservableList<Local> selectedLocals, allLocals;
        allLocals = tableview.getItems();
        selectedLocals = tableview.getSelectionModel().getSelectedItems();
        Local local = (Local) tableview.getSelectionModel().getSelectedItem();
        int id = local.getId_Local();
        su.delete(local, id);
        selectedLocals.forEach(allLocals::remove);
        
    }

    @FXML
    private void Modifier(ActionEvent event) {
          Local local =(Local)tableview.getSelectionModel().getSelectedItem();
          new_nom.setText(local.getNom_local());
          new_superficie.setText(String.valueOf(local.getSuperficie()));
          new_localisation.setText(local.getLocalisation());
          new_description.setText(local.getDescription());
          int id = local.getId_Local();

    }
           
    

       @FXML
    private void submit(ActionEvent event) throws SQLException {
          Local local =(Local)tableview.getSelectionModel().getSelectedItem();
         
           int  id = local.getId_Local();

        String req = "UPDATE `local` SET `description`=?,`nom_local`=?,`superficie`=? ,`localisation`=?  WHERE id_local=" + id;
        PreparedStatement ste1 = con.prepareStatement(req);
        ste1.setString(1, String.valueOf(new_description.getText()));
        ste1.setString(2, String.valueOf(new_nom.getText()));
        ste1.setString(3, String.valueOf(new_superficie.getText()));
        ste1.setString(4, String.valueOf(new_localisation.getText()));

        ste1.executeUpdate();
        
        System.out.println(ste1.execute());
        System.out.println("update avec succès");

    }

   
}
    
    

