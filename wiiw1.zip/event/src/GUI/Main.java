/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.io.IOException;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

/**
 *
 * @author CHAIMA
 */
public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) throws IOException {
      
//  
       Parent root = FXMLLoader.load(getClass().getResource("PremiereFenetre.fxml"));
     
        Scene scene = new Scene(root,800, 600);
//           final WebView webView = new WebView(); 
//       final WebEngine webEngine = new WebEngine();
//        final Scene scene = new Scene(webView, 350, 300); 
        primaryStage.setTitle("Test de chargement de WebView"); 
        primaryStage.setScene(scene); 
        primaryStage.show(); 
//        
//     
//      
//               
//       webView.getEngine().load(getClass().getResource("Connector.html").toExternalForm()); 
        
   
   
 
    }
 
  

        
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
