/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import com.jfoenix.controls.*;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.*;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;
import entities.Produit;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import service.ServiceProduit;
import service.ServiceUser;

/**
 * FXML Controller class
 *
 * @author Amine
 */
public class VendeurController implements Initializable {

    @FXML
    private AnchorPane anchor1;
    private JFXDrawer drawer;
    private JFXHamburger hamburger;
    @FXML
    private AnchorPane a1;
    @FXML
    private JFXTextField nomP;
    @FXML
    private Slider qtt;
    @FXML
    private JFXTextField prix;
    @FXML
    private TextArea desc;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
     /*   HamburgerBackArrowBasicTransition burgerTask= new HamburgerBackArrowBasicTransition(hamburger);
        burgerTask.setRate(-1);
        EventHandler Ham = new EventHandler() {
            @Override
            public void handle(Event event) {
                burgerTask.setRate(burgerTask.getRate()* -1);
            burgerTask.play();
              if(drawer.isShown())
             drawer.isHidden();
        else
            drawer.isHidden();
        }
        };*/
     //  hamburger.addEventHandler(Mouse, Ham);
         a1.toBack();
 
}

    private void ajoutProduit (ActionEvent event){
        
        Produit u = new Produit (//ref.getText(),
                nomP.getText(),
                Float.parseFloat(prix.getText()),
                (int) qtt.getValue(),
                desc.getText()
                 );
        ServiceProduit su = new ServiceProduit();
        try {
            su.AjouterProduit(u);
        } catch (SQLException ex) {
            Logger.getLogger(VendeurController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
//    private void annuler (MouseEvent event) {
//        
//      JFXDialogLayout content = new JFXDialogLayout();
//        content.setHeading(new Text("vous êtes sur d'annuler l'insertion ?"));
//        content.setBody(new Text("si vous annulez tout les données seront perdu\n"+
//                "\tAppuyez annuler pour retourner\n"+
//                 "\tAppuyez annuler accéder au page accueil"));
//        JFXButton buttonOK = new JFXButton("OK");
//        JFXButton buttonCancel = new JFXButton("Annuler");
//        buttonOK.setOnAction(new EventHandler<ActionEvent>(){
//            @Override
//            public void handle(ActionEvent event) {
//                        try {
//                        Parent page1 = FXMLLoader.load(getClass().getResource("/x/x/x/PAGE D ACCUEIL.FXML"));
//                        Scene scene = new Scene(page1);
//                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//                        stage.hide();
//                        stage.setScene(scene);
//                        stage.show();
//                        } catch (IOException ex) {
//                            Logger.getLogger(AccueilController.class.getName()).log(Level.SEVERE, null, ex);
//                             }
//                        
//            }
//        });
//        buttonCancel.setOnAction(new EventHandler<ActionEvent>(){
//            @Override
//            public void handle(ActionEvent event) {
//               dialog.close();
//            }
//            
//        });
//        content.setActions(buttonOK,buttonCancel);
//        dialog.show();
//    }
          }