/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import entities.User;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import service.ServiceUser;
import utils.DataSource;

/**
 * FXML Controller class
 *
 * @author CHAIMA
 */
public class AffichageUserController implements Initializable {
    
 
    
    public Connection con = DataSource.getInstance().getConnection() ;
    public Statement ste;
    
    @FXML
    private TableView<User> tableview;
    private ObservableList<User> data;
    @FXML
    private TableColumn<User, Integer> id=new TableColumn<>();
    @FXML
    private TableColumn<User, String> cin=new TableColumn<>();
    @FXML
    private TableColumn<User, String> nom=new TableColumn<>();
    @FXML
    private TableColumn<User, String> prenom=new TableColumn<>();
    @FXML
    private TableColumn<User, String> email=new TableColumn<>();
    @FXML
    private TableColumn<User, String> pwd=new TableColumn<>();
    @FXML
    private TableColumn<User, LocalDate> dateN=new TableColumn<>();
    @FXML
    private TableColumn<User, Integer> numTel=new TableColumn<>();
    @FXML
    private TableColumn<User, String> userName=new TableColumn<>();
    @FXML
    private TableColumn<User, String> image=new TableColumn<>();
    @FXML
    private TableColumn<User, String> adress=new TableColumn<>();
    @FXML
    private TableColumn<User, String> role=new TableColumn<>();

    
    
    public AffichageUserController(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        User u = new User();
        id.setCellValueFactory(new PropertyValueFactory<User, Integer>("id"));
        cin.setCellValueFactory(new PropertyValueFactory<User, String>("cin"));
        nom.setCellValueFactory(new PropertyValueFactory<User, String>("nom"));
        prenom.setCellValueFactory(new PropertyValueFactory<User, String>("prenom"));
        email.setCellValueFactory(new PropertyValueFactory<User, String>("email"));
        pwd.setCellValueFactory(new PropertyValueFactory<User, String>("pwd"));
        dateN.setCellValueFactory(new PropertyValueFactory<User, LocalDate>("dateN"));
        numTel.setCellValueFactory(new PropertyValueFactory<User, Integer>("numTel"));
        userName.setCellValueFactory(new PropertyValueFactory<User, String>("userName"));
        image.setCellValueFactory(new PropertyValueFactory<User, String>("image"));
        adress.setCellValueFactory(new PropertyValueFactory<User, String>("adress")); 
        role.setCellValueFactory(new PropertyValueFactory<User, String>("role"));
        buildData();

      /*  try {
            String req = "SELECT * FROM user";
            PreparedStatement ste =con.prepareStatement(req);
            ResultSet resultat = ste.executeQuery(req);
                    data = FXCollections.observableArrayList();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceUser.class.getName()).log(Level.SEVERE, null, ex);
        }*/  
    }    

    private void buildData() {
       ServiceUser su = ServiceUser.getInstance();
        data=FXCollections.observableArrayList();
       
        try {
             ResultSet r=su.afficher();
            while(r.next()){
                
                User u = new User();
                u.setId(r.getInt("id"));
                u.setCin(r.getString("cin"));
                u.setNom(r.getString("nom"));
                u.setPrenom(r.getString("prenom"));
                u.setEmail(r.getString("email"));
                u.setPwd(r.getString("pwd"));
                u.setDateNaissance(r.getDate("dateN"));
                u.setNumTel(r.getInt("numTel"));
                u.setUsername(r.getString("userName"));
                u.setImage(r.getString("image"));
                u.setAdresse(r.getString("adress"));
                u.setRole(r.getInt("role"));
               
              data.add(u);
            }
            tableview.setItems(null);
            tableview.setItems(data);
         } catch (SQLException ex) {
            Logger.getLogger(AffichageUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
