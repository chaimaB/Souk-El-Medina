/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package event;
import entities.*;
import entities.Reservation;
import entities.User;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import service.*;
import service.ServiceReservation;
import service.ServiceUser;
/**
 *
 * @author CHAIMA
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
  /*   User   user1 = new User(0,"04745", "fares", "mag", "fares@luf", "pwd",new Date(119,00,05), 25252525, "username", "image", "adresse", 1);
     
     
     ServiceUser su= new ServiceUser();
     
        try {
            su.AjouterUser(user1);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
            su.supprimer(1);
            su.update(user1, 2);*/
     /////////////////////////////////////////////////////////////////////////////////////////
    //    Event event = new Event();
        Event event= new Event(11, "a",new Date(118,00,04),"des", "image", "lieu", "prix",1);
        /*Event event1= new Event(2, "a",new Date(118,00,04),"des", "image", "lieu", "prix");
        Event event2= new Event(3, "a",new Date(118,00,04),"des", "image", "lieu", "prix");
        Event event3= new Event(4, "a",new Date(118,00,04),"des", "image", "lieu", "prix");*/
        ServiceEvent se= new ServiceEvent();
        
         /*   try {
            se.AjouterEvent(event);
            //se.AjouterEvent(event1);se.AjouterEvent(event2);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        
        System.out.println("Veuillez saisir le nouveau nom");
        String nomM=sc.next();
        event.setNom(nomM);
        
       /* System.out.println("Veuillez saisir la nouvelle date");
        String dateM=sc.next();
        event1.setDate(dateM);*/
        
    /*    System.out.println("Veuillez saisir la nouvelle description");
        String desM=sc.next();
        event.setDescription(desM);*/
        
         /*  System.out.println("Veuillez saisir le nouveau url de votre image");
     String imageM=sc.next();
        event1.setImage(imageM);
        
        System.out.println("Veuillez saisir le nouveau lieu");
        String lieuM=sc.next();
        event1.setLieu(lieuM);
        
        System.out.println("Veuillez saisir le nouveau prix");
        String prixM=sc.next();
        event1.setPrix(prixM);*/
        //sc.nextLine();
    
       // event.setDescription("aaa");
       // se.UpdateEvent(event);
        //se.SupprimerEvent(3);
        /////////////////////////////////////////////////////////////////////////////////////////////////
       // Event ev= new Event(1,"chaima",new Date(118,02,02), "description", "image", "lieu", "prix");
    /*    Event ev1= new Event(1,"aaaaaa",new Date(118,02,02), "description", "image", "lieu", "prix",1);
        String nomEv=ev1.getNom();
        String owner=user1.getNom();
        Reservation res1 = new Reservation(2,new Date(118,00,01), new Date(118,00,01),nomEv,owner);
        
        ServiceReservation sr= new ServiceReservation();*/
      /*  try {
            sr.AjouterReservation(res1);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        
      //  sr.SupprimerReserevation(1);
     // sr.UpdateReservation(res1, 2);
      
      ///////////////////////////////////////////////////
    /*  Commande cmd=new Commande(1,new Date(118,02,01), 100);
      ServiceCommande scmd = new ServiceCommande();*/
       /* try {
            scmd.AjouterCommande(cmd);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }*/
      // scmd.updatecommande(cmd,1);
      // scmd.supprimerCommande(1);
       
       ////////////////////////////////////////////////
     /*  Produit p = new Produit(1, "nomP", 100, "nomV",new Date(118,02,02));
       ServiceProduit sp=new ServiceProduit();*/
      /*  try {
            sp.AjouterProduit(p);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }*/
//      sp.UpdateProduit(p, 1);
//      sp.SupprimerProduit(1);
      ///////////////////////////////////////
    /*  Local l=new Local("des", "nom_local", 10, 10, "localisation", "imgl1", 0, 0);
      ServiceLocal sl=new ServiceLocal();*/
       /* try {
            sl.AjouterLocal(l);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }*/
//       sl.update(l, 1);
//       sl.supprimer(1);
    ///////////////////////////////////////////
//    Locaux_event le=new Locaux_event("description", "nom_local", 0, 0, "localisation", "imgl1", 0);
//    ServiceLocaux_event sle = new ServiceLocaux_event();
      /*  try {
            sle.AjouterLocal(le);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }*/
//      sle.update(le, 1);
//      sle.supprimer(1);
      
      ////////////////////////////////////////////////
    /*  Reclamation rec= new Reclamation(1, "reclameur", "reclamee", 1,new Date(118,02,07));
      ServiceReclamation srec = new ServiceReclamation();
        try {
            srec.AjouterReclamation(rec);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
        srec.update(rec, 1);
        srec.supprimer(1);*/
        /////////////////////////////////////////////
    /*    Commentaire cmtr = new Commentaire("contenu1",new Date(118,02,01));
        ServiceCommentaire scmtr = new ServiceCommentaire();
        try {
            scmtr.AjouterCommentaire(cmtr);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
        scmtr.update(cmtr, 1);
        scmtr.supprimer(1);*/
    }
    
}
