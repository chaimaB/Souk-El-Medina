/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;

/**
 *
 * @author CHAIMA
 */
public class Event {
     private int id_event ;
    private String nom ;
    private Date date;
    private  String description;
    private String image ;
    private  String lieu;
    private  String prix;
    public int owner;
  
    private static Event connectEvent;

    public Event(String nom) {
        this.nom=nom;
    }
    

    public Event(int id_event, String nom, Date date, String description, String image, String lieu, String prix, int owner) {
        this.id_event = id_event;
        this.nom = nom;
        this.date = date;
        this.description = description;
        this.image = image;
        this.lieu = lieu;
        this.prix = prix;
        this.owner=owner;
    }

    public int getOwner() {
        return owner;
    }

    public void setOwner(int owner) {
        this.owner = owner;
    }
    

    public int getId_event() {
        return id_event;
    }

    public String getNom() {
        return nom;
    }

    public Date getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public String getImage() {
        return image;
    }

    public String getLieu() {
        return lieu;
    }

    public String getPrix() {
        return prix;
    }

    public void setId_event(int id_event) {
        this.id_event = id_event;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setLieu(String lieu) {
        this.lieu = lieu;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }

    public void setDate(String dateM) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
