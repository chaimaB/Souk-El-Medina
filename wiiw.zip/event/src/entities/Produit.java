/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;

/**
 *
 * @author CHAIMA
 */
public class Produit {
     private int ref ;
     private String nomP;
     private float prix;
     private String img;
     private int qtt;
     private String desc;
     private String nomV;
     private Date dateAjout;

    public Produit(int ref, String nomP, float prix, String img, int qtt, String desc, String nomV, Date dateAjout) {
        this.ref = ref;
        this.nomP = nomP;
        this.prix = prix;
        this.img = img;
        this.qtt = qtt;       
        this.desc = desc;
        this.nomV = nomV;
        this.dateAjout = dateAjout;
    }
    
    public Produit (String nomP, float prix, int qtt, String desc){
        
        this.nomP = nomP;
        this.prix = prix;    
        this.qtt = qtt;       
        this.desc = desc;
        
    }

    public int getRef() {
        return ref;
    }

    public String getNomP() {
        return nomP;
    }

    public float getPrix() {
        return prix;
    }

    public String getImg() {
        return img;
    }

    public int getQtt() {
        return qtt;
    }

    public String getDesc() {
        return desc;
    }

    public String getNomV() {
        return nomV;
    }

    public Date getDateAjout() {
        return dateAjout;
    }

    public void setRef(int ref) {
        this.ref = ref;
    }

    public void setNomP(String nomP) {
        this.nomP = nomP;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public void setQtt(int qtt) {
        this.qtt = qtt;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setNomV(String nomV) {
        this.nomV = nomV;
    }

    public void setDateAjout(Date dateAjout) {
        this.dateAjout = dateAjout;
    }
     
     


     
     
}
