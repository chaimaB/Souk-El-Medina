/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author CHAIMA
 */
public class Local {
    private int id_Local;
    private String description ;
    private String nom_local;
    private float prix;
    private float superficie ;
    private String localisation;
    private String imgl1;
    private int type;
    public int prop;

    public Local(String description, String nom_local, float prix, float superficie, String localisation, String imgl1, int type, int prop) {
        this.description = description;
        this.nom_local = nom_local;
        this.prix = prix;
        this.superficie = superficie;
        this.localisation = localisation;
        this.imgl1 = imgl1;
        this.type = type;
        this.prop = prop;
    }

    public int getId_Local() {
        return id_Local;
    }

    public void setId_Local(int id_Local) {
        this.id_Local = id_Local;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNom_local() {
        return nom_local;
    }

    public void setNom_local(String nom_local) {
        this.nom_local = nom_local;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public float getSuperficie() {
        return superficie;
    }

    public void setSuperficie(float superficie) {
        this.superficie = superficie;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public String getImgl1() {
        return imgl1;
    }

    public void setImgl1(String imgl1) {
        this.imgl1 = imgl1;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getProp() {
        return prop;
    }

    public void setProp(int prop) {
        this.prop = prop;
    }
    
    
    
}
